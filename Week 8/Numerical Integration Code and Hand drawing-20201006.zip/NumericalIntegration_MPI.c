#include <stdio.h>
#include <math.h>
#include "mpi.h"

double f(double x);
double trapezoidBook(double a, double b, int n, int p, int rank);

int main(int argc, char *argv[])
{      
	int rank, value = 0, processorCount;

	MPI_Init(&argc, &argv); 
	MPI_Comm_rank(MPI_COMM_WORLD, &rank); 
	MPI_Comm_size(MPI_COMM_WORLD, &processorCount);
	
	double a = 0, b = 0, integralValue = 0; 
	int n = 0; 


	if(rank == 0)
	{
		fflush(stdout);
		printf("Enter the the integration lower limit:\n");
		scanf("%lg", &a);
		printf("Enter the the integration upper limit:\n");
		scanf("%lg", &b);
		printf("Enter the maximum number of iterations allowed:\n");
		scanf("%d", &n);
	}

	MPI_Bcast(&a, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
	MPI_Bcast(&b, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
	MPI_Bcast(&n, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
	MPI_Barrier(MPI_COMM_WORLD);

	// Integrate based on trapezoid method
	integralValue = trapezoidBook(a, b, n, processorCount, rank); 

	double totalintegralValue = 0;
	MPI_Reduce(&integralValue, &totalintegralValue, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

	if(rank == 0)
	{
		fflush(stdout);
		printf("The value of the integral (Book) is: %g\n", totalintegralValue);
	}
    
	MPI_Finalize();
	return 0; 
}

double f(double x)
{
	// function f(x) =  1 + x^2
	return 1 + pow(x, 2); 
}

double trapezoidBook(double a, double b, int n, int p, int rank) 
{
	double x;
	double dx = (b - a) / (float)(n);

	int intervalPerProcess  = n / p; // epr
	int intervalPerProcessRemain = n % p; // eprr

	double start = 0;
	double end = 0;
	double trapezoidArea = 0.0, totalArea = 0.0;

	start = a + (rank * (intervalPerProcess * dx));
	if(rank == (p - 1))
	{
		// Last processor, factor in the remainder
		end = start + (intervalPerProcess * dx) + (intervalPerProcessRemain * dx);
	}
	else
	{
		end = start + (intervalPerProcess * dx);
	}

	for(x = start; x < end; x += dx) 
	{
		trapezoidArea = (0.5 * dx * (f(x) + f(x + dx)));
		totalArea += trapezoidArea;
	}
	
	return totalArea; 
}
