#include <stdio.h>
#include <math.h>

double f(double x);
double trapezoidBook(double a, double b, int n);

int main(int argc, char *argv[])
{      
	double a = 0, b = 0, integralValue = 0; 
	int n = 0; 

	printf("Enter the the integration lower limit:\n");
	scanf("%lg", &a);
	printf("Enter the the integration upper limit:\n");
	scanf("%lg", &b);
	printf("Enter the maximum number of iterations allowed:\n");
	scanf("%d", &n);

	// Integrate based on trapezoid method
	integralValue = trapezoidBook(a, b, n); 

	printf("The value of the integral (Book) is: %g\n", integralValue);
  
	return 0; 
}

double f(double x)
{
	// function f(x) =  1 + x^2
	return 1 + pow(x, 2); 
}

double trapezoidBook(double a, double b, int n) 
{
	double x;
	double dx = (b - a) / (float)(n);
	double trapezoidArea = 0.0, totalArea = 0.0;
	//Why += dx? a = 1.5
	for(x = a; x < b; x += dx) 
	{
		trapezoidArea = (0.5 * dx * (f(x) + f(x + dx)));
		totalArea += trapezoidArea;
	}
	
	return totalArea; 
}
